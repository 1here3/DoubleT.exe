@echo off
color 04
echo 524.288 seconds
start 1.exe
start a.exe
echo 525
timeout 263
taskkill /f /im a.exe
timeout 262
start a.exe
taskkill /f /im a.exe
taskkill /f /im 1.exe